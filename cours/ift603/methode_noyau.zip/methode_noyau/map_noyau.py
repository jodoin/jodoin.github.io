# -*- coding: utf-8 -*-

#####
# Vos Noms (Vos Matricules) .~= À MODIFIER =~.
###

import numpy as np
import matplotlib
import matplotlib.pyplot as plt


class MAPnoyau:
    def __init__(self, lamb=0.5, sigma_square=1.0, c=0.1, M=9, noyau='rbf'):
        """
        Classe effectuant de la segmentation de données 2D 2 classes à l'aide de la méthode à noyau.

        lamb: coefficiant de régularisation L2.  Plus lamb est élevé, plus la surface de séparation est lisse
        sigma_square: paramètre du noyau rbf
        M,c: paramètres du noyau polynomial
        noyau: rbf ou polynomial
        """
        self.lamb = lamb
        self.a = None
        self.sigma_square = sigma_square
        self.M = M
        self.c = c
        self.noyau = noyau
        self.x_train = None

    def k(self, x, x_prime):
        """
        Calcule la distance "kernel" entre 2 vecteurs x et x_prime
        """

        # Noyau gaussien
        def k_rbf(x, x_prime, s2):
            return np.exp(-np.dot(x - x_prime, (x - x_prime).T) / (2 * s2))

        # Noyau polynomial
        def k_pol(x, x_prime, c, M):
            return np.power(np.dot(x, x_prime) + c, M)

        if self.noyau == 'rbf':
            val = k_rbf(x, x_prime, self.sigma_square)
        else:
            val = k_pol(x, x_prime, self.c, self.M)

        return val

    def entrainement(self, x_train, t_train):
        """
        Entraîne une méthode d'apprentissage à noyau de type Maximum a
        posteriori (MAP) avec un terme d'attache aux données de type
        "moindre carrés" et un terme de lissage quadratique
        """
        k_gramm = np.array([[self.k(x, x_prime) for x_prime in x_train] for x in x_train])

        phi_mat = k_gramm + self.lamb * np.identity(t_train.size)
        phi_mat_Inv = np.linalg.inv(phi_mat)
        self.a = phi_mat_Inv.dot(t_train)
        self.x_train = x_train

    def prediction(self, x):
        """
        Retourne la prédiction pour une entrée representée par un tableau
        1D Numpy ``x``.

        Cette méthode suppose que la méthode ``entrainement()`` a préalablement
        été appelée. Elle doit utiliser le champs ``self.a`` afin de calculer
        la prédiction y(x) (équation 6.9).

        NOTE : Puisque nous utilisons cette classe pour faire de la
        classification binaire, la prediction est +1 lorsque y(x)>0.5 et 0
        sinon
        """
        K = np.array([[self.k(x_, x_prime) for x_ in x] for x_prime in self.x_train])
        pred = (K.T.dot(self.a) > 0.5)
        return pred * 1.0

    def erreur(self, t, prediction):
        """
        Retourne la différence au carré entre
        la cible ``t`` et la prédiction ``prediction``.
        """
        return (t - prediction) ** 2

    def affichage(self, x_train, t_train, x_test, t_test, accu_train, accu_test):
        """Affiche les données et la frontière de décision du classifieur entraîné
        x_train: données d'entrainement 2D
        t_train: étiquettes d'entrainement (0 ou 1)
        x_test: données de test 2D
        t_test: étiquettes de test (0 ou 1)
        accu_train : justesse du modèle sur les données d'entrainement
        accu_test : justesse du modèle sur les données test
        """

        # Affichage
        matplotlib.use('TkAgg')
        x_min_plot = np.minimum(x_train[:, 0].min(), x_test[:, 0].min())
        x_max_plot = np.maximum(x_train[:, 0].max(), x_test[:, 0].max())
        y_min_plot = np.minimum(x_train[:, 1].min(), x_test[:, 1].min())
        y_max_plot = np.maximum(x_train[:, 1].max(), x_test[:, 1].max())

        ix = np.arange(x_min_plot, x_max_plot, 0.01)
        iy = np.arange(y_min_plot, y_max_plot, 0.01)
        iX, iY = np.meshgrid(ix, iy)
        x_vis = np.hstack([iX.reshape((-1, 1)), iY.reshape((-1, 1))])
        contour_out = np.array([self.prediction(x[None, :]) for x in x_vis])
        contour_out = contour_out.reshape(iX.shape)

        fig, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, figsize=(10, 4))

        ax1.contourf(iX, iY, np.uint8(contour_out > 0.5))
        ax1.scatter(x_train[:, 0], x_train[:, 1], s=(t_train + 0.5) * 100, c=t_train, edgecolors='y')
        ax1.set_title('Données d\'entrainement \n justesse = {:.1f}%'.format(accu_train))

        ax2.contourf(iX, iY, np.uint8(contour_out > 0.5))
        ax2.scatter(x_test[:, 0], x_test[:, 1], s=(t_test + 0.5) * 100, c=t_test, edgecolors='y')
        ax2.set_title('Données de test \n justesse = {:.1f}%'.format(accu_test))

        plt.tight_layout()
        plt.show()

