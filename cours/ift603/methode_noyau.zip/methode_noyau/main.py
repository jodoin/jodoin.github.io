# -*- coding: utf-8 -*-
"""
Execution de code de classification par méthode à noyau

Fait par Pierre-Marc Jodoin
Date: 12-2025
"""

import argparse
import numpy as np

import gestion_donnees as gd

from map_noyau import MAPnoyau

example = '''Exemples:

    python main.py polynomial 20 20 
    python main.py rbf 15 40 
    
'''


def get_arguments():
    parser = argparse.ArgumentParser(
        prog="segmentation par méthode à noyau",
        epilog=example,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('type_noyau',
                        choices=['rbf', 'polynomial'],
                        default='rbf',
                        help='Choix de la fonction du noyau.')
    parser.add_argument('nb_train', type=int, default=280,
                        help='Nombre de données d\'entraînement.')
    parser.add_argument('nb_test', type=int, default=280,
                        help='Nombre de données de test.')
    parser.add_argument('-M', type=int, default=8,
                        help='Paramètre du noyau polynomial.')
    parser.add_argument('-S', type=float, default=0.5,
                        help='Paramètre du noyau RBF.')

    return parser


def main():
    p = get_arguments()
    args = p.parse_args()

    type_noyau = args.type_noyau
    nb_train = args.nb_train
    nb_test = args.nb_test
    S2 = args.S
    M = args.M

    # On génère les données d'entraînement et de test
    generateur_donnees = gd.GestionDonnees(nb_train, nb_test)
    [x_train, t_train, x_test, t_test] = generateur_donnees.generer_donnees()

    # On entraine le modèle
    # sigma_square : paramètre du noyau RBF.  Plus il est petit, plus le modèle overfit
    # M : paramètre du noyau polynomial.  Plus il est gran, plus le modèle overfit
    mp = MAPnoyau(lamb=0.1, sigma_square=S2, M=M, noyau=type_noyau)
    mp.entrainement(x_train, t_train)

    # Prédictions sur les ensembles d'entraînement et de test
    predictions_entrainement = mp.prediction(x_train)
    accu_train = 100 - 100 * np.mean(mp.erreur(t_train, predictions_entrainement))
    print("Justesse d'entrainement = ", accu_train, "%")

    predictions_test = mp.prediction(x_test)
    accu_test = 100 - 100 * np.mean(mp.erreur(t_test, predictions_test))
    print("Justesse de test = ", accu_test, "%")

    # Affichage
    mp.affichage(x_train, t_train, x_test, t_test, accu_train, accu_test)


if __name__ == "__main__":
    main()
