# TP1 et TP2 - IFT780 Réseaux neuronaux
## Installation
Installer les dépendances dans un environnement python
```
$ pip3 install -r requirements.txt
```
Exécuter les commandes suivantes dans un terminal
```
$ cd datasets/
$ ./get_datasets.sh

ainsi que ces deux lignes pour le TP2

$ cd ../utils/cython/
$ ./build_cython.sh
```
## Pour commencer le travail!
Ouvrir les notebooks avec JupyterLab ou un éditeur de votre choix
```
$ jupyter lab
```
