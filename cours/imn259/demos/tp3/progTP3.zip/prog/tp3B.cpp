#include "MImage.h"
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>

/* 
	Zero Crossing
*/
int main(int argc, char*argv[])
{
	MImage img;
	MImage imgLaplacian;
	
	if(argc<3){
		cout << "Erreur: arguments manquants. Arguments a fournir: image threshold" << endl;
		exit(1);
	}
	
	/* Load input image and test the Laplacian filter */
	img.LoadImage(argv[1]);
	
	imgLaplacian = img;
	imgLaplacian.LaplacianFilter();
	imgLaplacian.Rescale();
	imgLaplacian.SaveImage("outLaplacian.pgm",PGM_RAW);

	/* Edge detection */
	img.ZeroCrossing(strtof(argv[2], nullptr));
	img.SaveImage("outZeroCrossing.pgm",PGM_RAW);
	
	return 0;
}
