#include "MImage.h"
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>


/* 
	Harris corner detector
*/
int main(int argc, char*argv[])
{
	MImage img;
	
	if(argc<5){
		cout << "Erreur: arguments manquants. Arguments a fournir: image threshold halfWinSize k" << endl;
		exit(1);
	}
	
	/* Load input image */
	img.LoadImage(argv[1]);
	
	/* Detecteur de Harris */
	img.HarrisCornerDetec(atoi(argv[3]),strtof(argv[4], nullptr)),
	img.Rescale();
	img.SaveImage("outHarris.pgm",PGM_RAW);

	img.Threshold(strtof(argv[2], nullptr));
	img.SaveImage("outHarrisThr.pgm",PGM_RAW);
	
	return 0;
}
