#include "MImage.h"
#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include <math.h>

/* 
	Non-maximum suppression
*/
int main(int argc, char*argv[])
{
	MImage img,imgGradX,imgGradY;
	
	if(argc<3){
		cout << "Erreur: arguments manquants. Arguments a fournir: image threshold" << endl;
		exit(1);
	}
	
	/* Load input image and test the gradient filters */
	img.LoadImage(argv[1]);
	
	imgGradX = img;
	imgGradX.GradientFilter(0);
	imgGradX.Rescale();
	imgGradX.SaveImage("gx.pgm",PGM_RAW);
	
	imgGradY = img;
	imgGradY.GradientFilter(1);
	imgGradY.Rescale();
	imgGradY.SaveImage("gy.pgm",PGM_RAW);
	
	/* Non-max suppression */
	img.NonMaxSupp();
	img.SaveImage("outNonMax.pgm",PGM_RAW);

	/* Threshold */
	img.Threshold(strtof(argv[2], nullptr));
	img.SaveImage("outNonMaxThr.pgm",PGM_RAW);
	
	return 0;
}
