#include "MImage.h"
#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include <math.h>
/* 
	Warping
*/
int main(int argc, char*argv[])
{
	MImage img1,img2;
	
	if(argc<2){
        cout << "Erreur: arguments manquants. Arguments a fournir: image" << endl;
		exit(1);
	}
	
	/* Load input images */
	img1.LoadImage(argv[1]);
	img2=img1;
	
	/* Warping with nearest neighbor */
	img1.WaveWarping(0);
	img1.SaveImage("outWarping0.ppm",PPM_RAW);

	/* Warping with bilinear interpolation */
	img2.WaveWarping(1);	
	img2.SaveImage("outWarping1.ppm",PPM_RAW);
	
	return 0;
}
