#include "MImage.h"
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <fstream>
#include <iostream>

using namespace std;

/*
	temporal median filter
*/
int main(int argc, char*argv[])
{
	MImage *imgTab;
	MImage medianImage;
	ifstream inputTextFile;
	string fileName;
	int nbInputImages;

	if(argc<2){
        cout << "Erreur: arguments manquants. Arguments a fournir: videoFiles.txt" << endl;
		exit(1);
	}

	/* Read text file  */
	inputTextFile.open(argv[1]);
	inputTextFile >> nbInputImages;

	imgTab = new MImage[nbInputImages];

	/* Read the "nbInputImages" images to be processed */
	for(int i=0;i<nbInputImages;i++){
		inputTextFile >> fileName;
		imgTab[i].LoadImage(fileName);
	}
	inputTextFile.close();

	/* Temporal median filter */
	medianImage = imgTab[0];
	medianImage.TemporalMedianFilter(imgTab,nbInputImages); // <--- To be modified
	medianImage.SaveImage("outTemporalMedianImage.ppm",PPM_RAW);

	/* Subtract the median image to each video frame */
	for(int i=0;i<nbInputImages;i++){
		imgTab[i] -= medianImage;
		imgTab[i].Abs();
		imgTab[i].RGBToGray();
		imgTab[i].Threshold(25);  // <--- Take the one from TP1

		imgTab[i].SaveImage("outVideoFile_" + std::to_string(i) + ".pgm", PGM_RAW);
	}

	delete []imgTab;

	return 0;
}
