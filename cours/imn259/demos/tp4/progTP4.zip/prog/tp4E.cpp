#include "MImage.h"


/* 
	Rescaled correlation
*/

int main(int argc, char*argv[])
{
	MImage img;
	MImage corr;
	
	if(argc<3){
		cout << "Erreur: arguments manquants. Arguments a fournir: image correlationImage" << endl;
		exit(1);
	}
	
	/* lire l'image d'entree */
    img.LoadImage(argv[1]);
    corr.LoadImage(argv[2]);

	/* calculer la correlation entre img et corr */
	img.RescaledCorrelationFilter(corr);
	img.Rescale();
	
	/* Sauvegarder le resultat */
	img.SaveImage("outRescCorr.ppm", PPM_RAW);

	return 0;
}
