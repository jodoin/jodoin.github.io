#include "MImage.h"


/* 
	High-pass gaussian Filter 
*/
int main(int argc, char*argv[])
{
	MImage img;
	MImage corr;
	
	if(argc<3){
		cout << "Erreur: arguments manquants. Arguments a fournir: image halfFiltersize" << endl;
		exit(1);
	}
		
	/* read input image */
	img.LoadImage(argv[1]);
	
	/* Apply high pass gaussian filter */
	img.HighpassGaussianFilter(strtof(argv[2], nullptr));
	img.Rescale();
	
	/* Save  */
	img.SaveImage("outHPG.ppm", PPM_RAW);

	return 0;
}
