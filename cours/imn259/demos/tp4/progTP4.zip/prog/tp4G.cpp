#include "MImage.h"


/* 
	Non-linear Diffusion with Perona-Malik
*/
int main(int argc, char*argv[])
{
	MImage img;
	
	if(argc<5){
		cout << "Erreur: arguments manquants. Arguments a fournir: image lambda nbIterations tau" << endl;
		exit(1);
	}
	
	/* Read input image */
    img.LoadImage(argv[1]);
	
	/* Apply NL diffusion */
	img.NonLinearDiffusionFilter(strtof(argv[2], nullptr), atoi(argv[3]), strtof(argv[4], nullptr));

	/* Save */
	img.SaveImage("outDiffusion.pgm", PGM_RAW);

	
	return 0;
}
