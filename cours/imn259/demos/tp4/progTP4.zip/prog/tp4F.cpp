#include "MImage.h"


/* 
	Median filter
*/

int main(int argc, char*argv[])
{
	MImage img;
	
	if(argc<3){
        cout << "Erreur: arguments manquants. Arguments a fournir: image halfwinsize" << endl;
		exit(1);
	}
	
	/* Read input image */
	img.LoadImage(argv[1]);

	/* Ajouter du bruit poivre et sel */
	for(int j=0;j< img.GetHeight();j++)
		for(int i=0;i< img.GetWidth();i++)
			for(int k=0;k< img.GetNumChannels();k++){
				if(rand()%100>90){
			
					if(rand()%100<50)
						img.SetColor(0, i, j, k);
					else
						img.SetColor(255, i, j, k);
				}
		}
	img.SaveImage("saltPepperImage.ppm", PPM_RAW);
	
	/* Filtrage median */
	img.MedianFilter(atoi(argv[2]));
	
	/* Sauvegarder le resultat */
	img.SaveImage("outMedian.ppm", PPM_RAW);

	return 0;
}
