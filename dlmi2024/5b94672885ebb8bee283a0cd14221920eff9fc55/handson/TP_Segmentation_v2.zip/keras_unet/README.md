# Keras-Unet

keras unet models and tools

use this repo in your own repo with
git submodule add https://gitlab.in2p3.fr/thomas.grenier/keras-unet.git keras_unet

and then clone your repo with somithing like:
git clone --recurse-submodules https://github.com/memyselfandI/myrepo.git

Have a look at this perfect git submodule page for more information about submodues:
https://git-scm.com/book/en/v2/Git-Tools-Submodules
