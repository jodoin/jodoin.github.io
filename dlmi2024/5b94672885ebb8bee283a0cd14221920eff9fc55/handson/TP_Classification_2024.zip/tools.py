import os
import glob
import requests
import numpy as np
from tqdm import tqdm
#import cv2
import matplotlib
import matplotlib.pyplot as plt
from PIL import Image

# display Image
def plot_image(image):
    plt.imshow(image, aspect="equal", cmap="gray", interpolation="nearest")
    plt.axis("off")  

def DisplayRGBImages(X_rgb, y, nb_x = 5, nb_y = 5, class_names = ['PD-A', 'PD-C', 'PD-S', 'T1-A', 'T1-C', 'T1-S', 'T2-A', 'T2-C', 'T2-S'] ):
    plt.figure(figsize=(15,15*nb_x/nb_y), dpi=100)
    for i in range(1, nb_x * nb_y +1):
        plt.subplot(nb_x, nb_y ,i)
        plot_image( X_rgb[i-1] )
        plt.title(class_names[y[i-1]])

# Reading images OpenCV version
#def ReadImages(images_files, desired_width, desired_height ):
#    X = []
#    for index in tqdm(range(len(images_files))):
#        image_read = cv2.imread(images_files[index], cv2.IMREAD_COLOR)
#        image_read = cv2.resize(image_read, dsize = (desired_width, desired_height), interpolation = cv2.INTER_LINEAR)
#        X.append(image_read)
#    X = np.asarray(X, dtype=np.uint8)
#    return X

# Reading images PIL version
def ReadImages(images_files, desired_width, desired_height ):
    X = []
    for index in tqdm(range(len(images_files))):
        image_read = Image.open(images_files[index])
        image_read = image_read.resize((desired_width, desired_height), resample = Image.Resampling.BICUBIC)
        image_read = np.array(image_read)
        image_read_rgb = np.expand_dims(image_read,-1)
        image_read_rgb = np.repeat(image_read_rgb, 3, axis=-1)
        X.append(image_read_rgb )
    X = np.asarray(X, dtype=np.uint8)
    return X

# Load the images for the hands-on   (class_ratio=[1, 1, 1, 1, 1, 1, 1, 1, 1] ) 
def ReadHandsOnData(train_test='train_val', randomize_image=True, validation_ratio=0.2, base_path=None, desired_height=64, desired_width=64, class_names = ['PD-A', 'PD-C', 'PD-S', 'T1-A', 'T1-C', 'T1-S', 'T2-A', 'T2-C', 'T2-S'], file_link="dlss_classification_A" ): 

    if base_path is None:
        base_path=os.getcwd()
    
    if not os.path.isfile(base_path+"/data/"+file_link+".tar.gz"):
        os.system('wget -P data "https://www.creatis.insa-lyon.fr/~grenier/wp-content/uploads/teaching/DeepLearning/"' + file_link + '.tar.gz')
        os.system('tar xzf ' + base_path+'/data/'+file_link+'.tar.gz -C data ')
    else:
        print(f" ** file {file_link}.tar.gz already downloaded, skipping downloading and untar \n Remove the file {base_path}/data/{file_link}.tar.gz to download it again. \n This is not an error :) " )
    
    if train_test=='train_val':    
        input_path = base_path+'/data/'+file_link+'/train'
    else:
        input_path = base_path+'/data/'+file_link+'/test'
            
    print(f"input train path : {input_path}")  
   
    # first list files for the train and validation sets.
    image_file_list = []
    label_list = []

    for i in range(len(class_names)):
        for filename in glob.iglob( os.path.join(input_path, class_names[i]) + '/**/*.png', recursive=True):
            # extract patient number and slice
            image_file_list.append(filename)
            label_list.append( i )     
    
    # Random permutation
    if randomize_image:
        permutation = np.random.permutation( len(label_list) )
        images_files=[image_file_list[i] for i in permutation]
        labels=[label_list[i] for i in permutation]
    
    if train_test=='train_val':
        # we split the train set in two parts : train and validation
        nb_train = int( len(label_list) * (1 - validation_ratio) )
        # list images for both datasets
        train_images_files = images_files[:nb_train]
        train_labels = labels[:nb_train]

        val_images_files = images_files[nb_train:]
        val_labels = labels[nb_train:]

        # convert labels to numpy
        y_train = np.asarray(train_labels)
        y_val = np.asarray(val_labels)
    
        X_train_rgb = ReadImages(train_images_files, desired_width, desired_height)
        X_val_rgb   = ReadImages(val_images_files,  desired_width, desired_height)
    
        # Show information
        print(" Shape : " , X_train_rgb.shape, X_val_rgb.shape)
        print(" Type  : %s  %s"%(X_train_rgb.dtype, X_val_rgb.dtype))
        print(" Max   : %d  %d"%(X_train_rgb.max(), X_val_rgb.max()))
        print(" Min   : %d  %d"%(X_train_rgb.min(), X_val_rgb.min()))
        print(" Labels Shape : " , y_train.shape, y_val.shape)
      
        return X_train_rgb, y_train, X_val_rgb, y_val
   
    else:
        X_test_rgb = ReadImages(image_file_list,  desired_width, desired_height)
        y_test = np.asarray(label_list)

        print(" Shape : " , X_test_rgb.shape, y_test.shape)
        print(" Type  : %s  %s"%(X_test_rgb.dtype, y_test.dtype))
        print(" Max   : %d  %d"%(X_test_rgb.max(), y_test.max()))
        print(" Min   : %d  %d"%(X_test_rgb.min(), y_test.min()))    
        return X_test_rgb, y_test
         