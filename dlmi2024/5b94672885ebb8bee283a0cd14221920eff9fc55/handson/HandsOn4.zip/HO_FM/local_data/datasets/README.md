Expected structure of this folder:

```
.
└── SICAPv2/
    ├── images/
    │   ├── 16B0001851_Block_Region_1_0_0_xini_6803_yini_59786.jpg
    │   └── ...
    ├── masks/
    │   ├── 16B0001851_Block_Region_1_0_0_xini_6803_yini_59786.png
    │   └── ...
    ├── partition/
    │   ├── Test/
    │   │   ├── Test.xlsx
    │   │   └── Train.xlsx
    │   └── Validation/
    │       └── ...
    ├── readme.txt
    └── wsi_labels.xlsx
```